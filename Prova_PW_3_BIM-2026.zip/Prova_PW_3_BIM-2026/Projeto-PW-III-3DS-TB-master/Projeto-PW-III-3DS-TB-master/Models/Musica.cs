﻿namespace Projeto_Cadastro_MVC_3DSTB.Models
{
    public class Musica
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Compositor { get; set; }
        public string? Album { get; set; }
        public double Ano { get; set; }

    }
}
