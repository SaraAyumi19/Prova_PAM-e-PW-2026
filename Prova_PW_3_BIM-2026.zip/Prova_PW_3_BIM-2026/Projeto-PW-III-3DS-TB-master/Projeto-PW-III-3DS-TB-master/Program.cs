using Microsoft.EntityFrameworkCore;
using Projeto_Cadastro_MVC_3DSTB.Data;
using Projeto_Cadastro_MVC_3DSTB.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var connectionString = 
    builder.Configuration.GetConnectionString("Database");

builder.Services.AddDbContext<DatabaseContext>(options =>
        options.UseMySql(
                connectionString,
                ServerVersion.AutoDetect(connectionString)
            )
    );

builder.Services
    .AddScoped<IMusicaRepository, MusicaRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
