﻿using Projeto_Cadastro_MVC_3DSTB.Models;

namespace Projeto_Cadastro_MVC_3DSTB.Repository
{
    public interface IMusicaRepository
    {
        List<Musica> BuscarTodos();
        Musica Adicionar(Musica musica);
        Musica? BuscarPorId(int id);
        void Atualizar(Musica musica);

        bool Excluir(int id);
    }
}
