﻿using Projeto_Cadastro_MVC_3DSTB.Data;
using Projeto_Cadastro_MVC_3DSTB.Models;

namespace Projeto_Cadastro_MVC_3DSTB.Repository
{
    public class MusicaRepository : IMusicaRepository
    {
        private readonly DatabaseContext dbContext;
        public MusicaRepository(DatabaseContext context)
        {
            dbContext = context;
        }

        public List<Musica> BuscarTodos()
        {
            return dbContext.Musicas.ToList();
        }

        public Musica Adicionar(Musica musica)
        {
            dbContext.Musicas.Add(musica);
            dbContext.SaveChanges();
            return musica;
        }

        public Musica? BuscarPorId(int id)
        {
            return dbContext.Musicas.FirstOrDefault(f => f.Id == id);
        }

        public void Atualizar(Musica musica)
        {
            Musica? func = BuscarPorId(musica.Id);

            if (func == null)
            {
                throw new Exception("Houve um erro na atualização!");
            }

            func.Nome = musica.Nome;
            func.Compositor = musica.Compositor;
            func.Album = musica.Album;
            func.Ano = musica.Ano;

            dbContext.Musicas.Update(func);
            dbContext.SaveChanges();
        }

        public bool Excluir(int id)
        {
            Musica? musica = BuscarPorId(id);

            if (musica == null)
                throw new Exception("Houve um erro na exclusão da Música!");

            dbContext.Musicas.Remove(musica);
            dbContext.SaveChanges();

            return true;
        }
    }
}
