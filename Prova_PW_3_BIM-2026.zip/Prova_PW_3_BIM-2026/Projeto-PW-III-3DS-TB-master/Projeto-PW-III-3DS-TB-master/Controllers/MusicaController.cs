﻿using Microsoft.AspNetCore.Mvc;
using Projeto_Cadastro_MVC_3DSTB.Models;
using Projeto_Cadastro_MVC_3DSTB.Repository;

namespace Projeto_Cadastro_MVC_3DSTB.Controllers
{
    public class MusicaController : Controller
    {
        private readonly IMusicaRepository funcRepository;

        public MusicaController(IMusicaRepository rep)
        {
            funcRepository = rep;
        }

        public IActionResult Index()
        {
            List<Musica> listaMusicas = funcRepository.BuscarTodos();
            return View(listaMusicas);
        }

        public IActionResult Criar()
        {
            ViewBag.TipoTela = "Criar";
            return View("~/Views/Musica/CriarEditar.cshtml");
        }

        public IActionResult Editar(int id)
        {
            Musica? musica = funcRepository.BuscarPorId(id);
            ViewBag.TipoTela = "Editar";
            return View("~/Views/Musica/CriarEditar.cshtml", musica);
        }

        [HttpPost]
        public IActionResult Criar(Musica musica)
        {
            funcRepository.Adicionar(musica);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Editar(Musica musica)
        {
            funcRepository.Atualizar(musica);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Excluir(Musica musica)
        {
            funcRepository.Excluir(musica.Id);
            return RedirectToAction("Index");
        }
    }
}
